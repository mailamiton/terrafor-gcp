import json


def lambda_handler(event, context):

    # TODO implement
    return {'body': json.dumps('Hello Lambda')}
   # return {'statuscode': 200, 'body': json.dumps('Hello Lambda')}
